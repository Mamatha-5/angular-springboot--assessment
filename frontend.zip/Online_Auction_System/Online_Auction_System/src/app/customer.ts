export class Customer{
    customerID!:number;
    customerName!:String;
    customerEmail!:String;
    customerPassword!:String;
    customerAddress!:String;
    customerNumber!:number;
}